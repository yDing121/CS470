/* THIS CODE IS MY OWN WORK, IT WAS WRITTEN WITHOUT CONSULTING CODE WRITTEN BY
OTHER STUDENTS. Yilang Ding */


# Environment

I am running a Python 3.12.6 virtual environment created using `python -m venv venv`. 
Required libraries are documented in `requirements.txt`, and can be installed via 
`pip install -r requirements.txt` after environment activation. The setup has been
tested with a clean install on x86 Windows 10 with Python 3.12.6.

# Notes

If you want to check out the development process, refer to the jupyter notebooks.
The actual Decision Tree Classifier is in `decision_tree.py`. The script takes four
input parameters as required by the homework statement. For usage instructions,
refer to the help output of argparse for the script: `python decision_tree.py -h`.
The script is set up to default to using the given file names in the same directory.
The report is in CS470_HW3.pdf